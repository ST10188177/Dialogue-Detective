// === BACKGROUND SLIDESHOW ===
const slides = document.querySelectorAll(".background-slideshow .slide");
let currentSlide = 0;

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.toggle("active", i === index);
  });
}

// Set background images
slides[0].style.backgroundImage = "url('Differenct.jpg')";
slides[1].style.backgroundImage = "url('lightbulb.jpg')";
slides[2].style.backgroundImage = "url('Micro.jpg')";
slides[3].style.backgroundImage = "url('newsroom 2.webp')";

// Auto-rotate slides
setInterval(() => {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}, 3500);

showSlide(currentSlide);

// === MINI-GAME LOGIC ===
const startBtn = document.getElementById("start-btn");
const nameForm = document.getElementById("name-form");
const quiz = document.getElementById("quiz");
const detectiveNameInput = document.getElementById("detective-name");
const questionText = document.getElementById("question-text");
const choicesDiv = document.getElementById("choices");
const feedback = document.getElementById("game-feedback");
const hint = document.getElementById("hint-message");
const progressBar = document.getElementById("progress-bar");
const restartBtn = document.getElementById("restart-btn");
const finalResult = document.getElementById("final-result");
const scoreMessage = document.getElementById("score-message");

let currentQuestion = 0;
let score = 0;
let detectiveName = "";

const quizQuestions = [
  {
    text: "Clue #1: Where is the brand voice most likely hidden?",
    choices: [
      { text: "Growth Logs", correct: true },
      { text: "Brand Identity Folder", correct: false },
    ],
    hint: "Think: where does strategic development get recorded?",
  },
  {
    text: "Clue #2: Which trait defines a strong brand voice?",
    choices: [
      { text: "Consistency", correct: true },
      { text: "Confusion", correct: false },
    ],
    hint: "Would a detective prefer a clue that changes often or stays consistent?",
  },
  {
    text: "Clue #3: Where would feedback from users be most valuable?",
    choices: [
      { text: "Support Chat Logs", correct: true },
      { text: "Archived Designs", correct: false },
    ],
    hint: "Where are real voices of users usually found?",
  },
];

function showQuizQuestion() {
  const q = quizQuestions[currentQuestion];
  questionText.textContent = q.text;
  choicesDiv.innerHTML = "";
  feedback.textContent = "";
  hint.textContent = "";

  q.choices.forEach((choice) => {
    const btn = document.createElement("button");
    btn.textContent = choice.text;
    btn.classList.add("case-btn");
    btn.addEventListener("click", () => handleAnswer(choice.correct));
    choicesDiv.appendChild(btn);
  });

  progressBar.value = (currentQuestion / quizQuestions.length) * 100;
}

function handleAnswer(isCorrect) {
  if (isCorrect) {
    score++;
    feedback.innerHTML = `✅ Well done, Detective ${detectiveName}!`;
    feedback.style.color = "var(--burgundy)";
  } else {
    feedback.innerHTML = `❌ Not quite, try again Detective.`;
    feedback.style.color = "var(--red)";
    hint.textContent = quizQuestions[currentQuestion].hint;
  }

  setTimeout(() => {
    currentQuestion++;
    if (currentQuestion < quizQuestions.length) {
      showQuizQuestion();
    } else {
      showFinalScore();
    }
  }, 1500);
}

function showFinalScore() {
  quiz.style.display = "none";
  finalResult.style.display = "block";
  progressBar.value = 100;
  scoreMessage.textContent = `🎯 Detective ${detectiveName}, you solved ${score} out of ${quizQuestions.length} clues.`;
}

function restartGame() {
  currentQuestion = 0;
  score = 0;
  finalResult.style.display = "none";
  quiz.style.display = "block";
  showQuizQuestion();
}

startBtn.addEventListener("click", () => {
  const name = detectiveNameInput.value.trim();
  if (!name) {
    alert("Please enter your name, Detective!");
    return;
  }
  detectiveName = name;
  nameForm.style.display = "none";
  quiz.style.display = "block";
  showQuizQuestion();
});

restartBtn.addEventListener("click", restartGame);

// === CARDS SLIDER ===
const grid = document.querySelector(".grid");
const prevBtn = document.querySelector(".prev-btn");
const nextBtn = document.querySelector(".next-btn");

let scrollAmount = 0;
const scrollStep = 320;

function scrollLeft() {
  scrollAmount = Math.max(scrollAmount - scrollStep, 0);
  grid.style.transform = `translateX(-${scrollAmount}px)`;
}

function scrollRight() {
  const maxScroll = grid.scrollWidth - grid.clientWidth;
  scrollAmount = Math.min(scrollAmount + scrollStep, maxScroll);
  grid.style.transform = `translateX(-${scrollAmount}px)`;
}

if (prevBtn && nextBtn) {
  prevBtn.addEventListener("click", scrollLeft);
  nextBtn.addEventListener("click", scrollRight);
}

// === BRAND QUESTIONS ===
const brandQuestions = [
  "1. If your brand was a person, what would their signature outfit be?",
  "2. What three words would others use to describe your brand's personality?",
  "3. How would your brand introduce itself at a networking event?",
  "4. What kind of humor does your brand have? (Witty, sarcastic, playful, etc.)",
  "5. If your brand had a spirit animal, what would it be and why?",
  "6. What values would be in your brand's personal mission statement?",
  "7. How does your brand respond to criticism or negative feedback?",
  "8. What would your brand's favorite book/movie be and why?",
  "9. If your brand could have dinner with any historical figure, who would it choose?",
  "10. What would your brand's social media personality be like?",
  "11. How would your brand handle a crisis or unexpected challenge?",
  "12. What kind of music would be on your brand's playlist?",
  "13. If your brand wrote an autobiography, what would the title be?",
  "14. What would your brand's ideal weekend look like?",
  "15. How would your brand celebrate major successes or milestones?",
  "16. What causes or social issues would your brand passionately support?",
  "17. If your brand had a superpower, what would it be and why?",
  "18. What would your brand's morning routine look like?",
  "19. How would your brand comfort someone who's having a bad day?",
  "20. What legacy does your brand want to leave in 10 years?"
];

const questionBox = document.getElementById("question-box");
const nextQuestionBtn = document.getElementById("next-question-btn");
const restartQuestionsBtn = document.getElementById("restart-questions-btn");

let currentQuestionIndex = 0;

function showQuestion(index) {
  questionBox.textContent = brandQuestions[index];
  questionBox.classList.add("animate");
  setTimeout(() => questionBox.classList.remove("animate"), 1000);
}

function nextQuestion() {
  currentQuestionIndex++;
  if (currentQuestionIndex >= brandQuestions.length) {
    questionBox.innerHTML = "Brand Personality Complete!<br><br>You've explored 20 dimensions of your brand identity.";
    nextQuestionBtn.style.display = "none";
    restartQuestionsBtn.style.display = "inline-block";
  } else {
    showQuestion(currentQuestionIndex);
  }
}

function restartQuestions() {
  currentQuestionIndex = 0;
  showQuestion(currentQuestionIndex);
  nextQuestionBtn.style.display = "inline-block";
  restartQuestionsBtn.style.display = "none";
}

if (questionBox && nextQuestionBtn && restartQuestionsBtn) {
  showQuestion(currentQuestionIndex);
  nextQuestionBtn.addEventListener("click", nextQuestion);
  restartQuestionsBtn.addEventListener("click", restartQuestions);
}

// === EASTER EGG ===
// === EASTER EGG ===
document.addEventListener("DOMContentLoaded", () => {
  const easterEgg = document.getElementById("easter-egg");
  const secretPopup = document.getElementById("secret-popup");
  const dykText = document.getElementById("dyk-text");

  const dykFacts = [
    "The word 'dialogue' comes from the Greek 'dia' (through) and 'logos' (speech).",
    "Good design is like a detective — it uncovers problems before they become crimes.",
    "Every great brand starts with a question — not an answer.",
    "Journalists and detectives share a core skill: pattern recognition.",
    "In communication theory, 'noise' isn't sound — it's anything that disrupts clarity.",
    "Case #005 was inspired by a real 1990s branding controversy.",
    "Detective fiction influenced modern UX storytelling techniques.",
    "🧠 Fun fact: Eye-tracking tech helps uncover unconscious user behavior.",
    "Your brand's voice reveals more than your visuals ever could.",
    "🕵️ The 'Growth Logs' contain metadata most users skip — but you didn't 😉."
  ];

  function showRandomDYK() {
    const randomIndex = Math.floor(Math.random() * dykFacts.length);
    dykText.textContent = dykFacts[randomIndex];
    secretPopup.style.display = "block";
  }

  if (easterEgg && secretPopup && dykText) {
    easterEgg.addEventListener("click", (e) => {
      e.stopPropagation();
      showRandomDYK();
    });

    document.addEventListener("click", (e) => {
      if (!secretPopup.contains(e.target) && e.target !== easterEgg) {
        secretPopup.style.display = "none";
      }
    });
  }
});


// === EMAIL FUNCTIONALITY ===
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function subscribeEmail(email) {
  console.log('Subscribing email:', email);
  // In production, replace with actual API call
  emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', { email })
    .then(response => console.log('Subscription sent!', response.status, response.text))
    .catch(error => console.error('Failed to send subscription:', error));
}

function submitContactForm(formData) {
  console.log('Submitting contact form:', formData);
  emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', formData)
    .then(response => console.log('Email sent!', response.status, response.text))
    .catch(error => console.error('Failed to send email:', error));
}

// === PAGE-SPECIFIC INITIALIZATION ===
function initBlogPage() {
  // Category filtering
  const categoryButtons = document.querySelectorAll('.category-btn');
  const blogCards = document.querySelectorAll('.blog-card');
  
  if (categoryButtons.length > 0) {
    categoryButtons.forEach(button => {
      button.addEventListener('click', () => {
        categoryButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const category = button.dataset.category;
        
        blogCards.forEach(card => {
          if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'block';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }
  
  // Newsletter subscription
  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const emailInput = this.querySelector('input[type="email"]');
      const email = emailInput.value.trim();
      
      if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        return;
      }
      
      subscribeEmail(email);
      
      const successMsg = document.createElement('p');
      successMsg.textContent = 'Thanks for subscribing! Check your email for confirmation.';
      successMsg.style.color = 'white';
      successMsg.style.marginTop = '1rem';
      
      this.parentElement.insertBefore(successMsg, this.nextSibling);
      this.reset();
      
      setTimeout(() => successMsg.remove(), 5000);
    });
  }
}

function initContactPage() {
  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = {
        name: this.querySelector('#name').value.trim(),
        email: this.querySelector('#email').value.trim(),
        service: this.querySelector('#service').value,
        message: this.querySelector('#message').value.trim()
      };
      
      if (!formData.name || !formData.email || !formData.message) {
        alert('Please fill in all required fields.');
        return;
      }
      
      if (!validateEmail(formData.email)) {
        alert('Please enter a valid email address.');
        return;
      }
      
      submitContactForm(formData);
      
      const submitBtn = this.querySelector('.submit-btn');
      const originalText = submitBtn.textContent;
      submitBtn.textContent = 'Message Sent!';
      submitBtn.style.backgroundColor = '#4CAF50';
      
      this.reset();
      
      setTimeout(() => {
        submitBtn.textContent = originalText;
        submitBtn.style.backgroundColor = 'var(--burgundy)';
      }, 3000);
    });
  }
  
  // FAQ accordion
  const faqQuestions = document.querySelectorAll('.faq-question');
  faqQuestions.forEach(question => {
    question.addEventListener('click', () => {
      const faqItem = question.parentElement;
      faqItem.classList.toggle('active');
      
      faqQuestions.forEach(q => {
        if (q !== question && q.parentElement.classList.contains('active')) {
          q.parentElement.classList.remove('active');
        }
      });
    });
  });
}

function initServicesPage() {
  // Testimonial slider
  const testimonials = document.querySelectorAll('.testimonial');
  let currentTestimonial = 0;
  
  if (testimonials.length > 1) {
    testimonials[0].classList.add('active');
    
    setInterval(() => {
      testimonials[currentTestimonial].classList.remove('active');
      currentTestimonial = (currentTestimonial + 1) % testimonials.length;
      testimonials[currentTestimonial].classList.add('active');
    }, 5000);
  }
  
  // Service inquiry links
  const serviceInquiryLinks = document.querySelectorAll('.service-cta');
  serviceInquiryLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      if (window.location.pathname.includes('contact.html')) {
        e.preventDefault();
        const service = link.closest('.service-card').querySelector('h2').textContent;
        document.querySelector('#service').value = service;
        document.querySelector('#message').value = `I'm interested in your ${service} service. Please provide more information.`;
        document.querySelector('#message').focus();
      }
    });
  });
}

// === MAIN INITIALIZATION ===
document.addEventListener('DOMContentLoaded', function() {
  // Initialize EmailJS (replace with your actual User ID)
  emailjs.init('YOUR_USER_ID');
  
  // Initialize page-specific functionality
  if (document.querySelector('.blog-grid')) initBlogPage();
  if (document.querySelector('.contact-form')) initContactPage();
  if (document.querySelector('.services-grid')) initServicesPage();
  
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
  });
  
  // Set current date in footer
  const dateElement = document.querySelector('.date');
  if (dateElement) {
    const currentDate = new Date();
    const options = { month: 'long', year: 'numeric' };
    dateElement.textContent = currentDate.toLocaleDateString('en-US', options).toUpperCase();
  }
});
// Initialize EmailJS (must be at the top)
emailjs.init('YOUR_USER_ID');

// === CONTACT FORM HANDLING ===
function initContactForm() {
  const contactForm = document.getElementById('contactForm');
  if (!contactForm) return;

  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const submitBtn = this.querySelector('.submit-btn');
    const statusElement = document.getElementById('form-status');
    
    // Change button to loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="loading-spinner"></span> Sending...';
    statusElement.textContent = '';
    
    // For Formspree - let it handle submission naturally
    if (this.action.includes('formspree.io')) {
      this.submit();
      return;
    }
    
    // For EmailJS
    const formData = {
      name: this.querySelector('#name').value.trim(),
      email: this.querySelector('#email').value.trim(),
      service: this.querySelector('#service').value,
      message: this.querySelector('#message').value.trim()
    };
    
    emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', formData)
      .then(response => {
        submitBtn.textContent = 'Message Sent!';
        submitBtn.style.backgroundColor = '#4CAF50';
        statusElement.textContent = 'Your message has been sent successfully!';
        statusElement.style.color = '#4CAF50';
        this.reset();
        
        setTimeout(() => {
          submitBtn.textContent = 'Send Message';
          submitBtn.style.backgroundColor = 'var(--burgundy)';
          submitBtn.disabled = false;
        }, 3000);
      })
      .catch(error => {
        console.error('Failed to send email:', error);
        submitBtn.textContent = 'Send Message';
        submitBtn.disabled = false;
        statusElement.textContent = 'Failed to send message. Please try again.';
        statusElement.style.color = '#ff4444';
      });
  });
}

// === FAQ ACCORDION ===
function initFAQAccordion() {
  const faqQuestions = document.querySelectorAll('.faq-question');
  if (faqQuestions.length === 0) return;

  faqQuestions.forEach(question => {
    question.addEventListener('click', () => {
      const faqItem = question.parentElement;
      faqItem.classList.toggle('active');
      
      // Close other open items
      faqQuestions.forEach(q => {
        if (q !== question && q.parentElement.classList.contains('active')) {
          q.parentElement.classList.remove('active');
        }
      });
    });
  });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  initContactForm();
  initFAQAccordion();
});

// === BLOG PAGE FUNCTIONALITY ===
function initBlogPage() {
  // Category filtering
  const categoryButtons = document.querySelectorAll('.category-btn');
  const blogCards = document.querySelectorAll('.blog-card');
  
  if (categoryButtons.length > 0 && blogCards.length > 0) {
    categoryButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault(); // Prevent default link behavior if it's an anchor
        
        // Update active button
        categoryButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const category = button.dataset.category || 'all'; // Fallback to 'all'
        
        // Filter blog cards
        blogCards.forEach(card => {
          if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'block';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }


// Initialize the blog page when DOM is loaded
document.addEventListener('DOMContentLoaded', initBlogPage);
  
  // Newsletter subscription
  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const emailInput = this.querySelector('input[type="email"]');
      const email = emailInput.value.trim();
      
      if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        return;
      }
      
      // Simulate subscription (in a real app, you'd send to your backend)
      subscribeEmail(email);
      
      // Show success message
      const successMsg = document.createElement('p');
      successMsg.textContent = 'Thanks for subscribing! Check your email for confirmation.';
      successMsg.style.color = 'white';
      successMsg.style.marginTop = '1rem';
      
      const formContainer = this.parentElement;
      formContainer.insertBefore(successMsg, this.nextSibling);
      
      // Reset form
      this.reset();
      
      // Remove message after 5 seconds
      setTimeout(() => {
        successMsg.remove();
      }, 5000);
    });
  }
}

// === CONTACT PAGE FUNCTIONALITY ===
function initContactPage() {
  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Get form data
      const formData = {
        name: this.querySelector('#name').value.trim(),
        email: this.querySelector('#email').value.trim(),
        service: this.querySelector('#service').value,
        message: this.querySelector('#message').value.trim()
      };
      
      // Validate
      if (!formData.name || !formData.email || !formData.message) {
        alert('Please fill in all required fields.');
        return;
      }
      
      if (!validateEmail(formData.email)) {
        alert('Please enter a valid email address.');
        return;
      }
      
      // Simulate form submission (in a real app, use fetch or AJAX)
      submitContactForm(formData);
      
      // Show success message
      const submitBtn = this.querySelector('.submit-btn');
      const originalText = submitBtn.textContent;
      submitBtn.textContent = 'Message Sent!';
      submitBtn.style.backgroundColor = '#4CAF50';
      
      // Reset form
      this.reset();
      
      // Reset button after 3 seconds
      setTimeout(() => {
        submitBtn.textContent = originalText;
        submitBtn.style.backgroundColor = 'var(--burgundy)';
      }, 3000);
    });
  }
  
  // FAQ accordion functionality
  document.addEventListener('DOMContentLoaded', () => {
  const faqQuestions = document.querySelectorAll('.faq-question');

  faqQuestions.forEach(question => {
    question.addEventListener('click', () => {
      const faqItem = question.parentElement;
      const answer = faqItem.querySelector('.faq-answer');
      const isActive = faqItem.classList.contains('active');

      // Close all items
      document.querySelectorAll('.faq-item').forEach(item => {
        item.classList.remove('active');
        const itemAnswer = item.querySelector('.faq-answer');
        itemAnswer.style.maxHeight = null;
      });

      // Open clicked item (if it wasn't already active)
      if (!isActive) {
        faqItem.classList.add('active');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });
});

}

// === SERVICES PAGE FUNCTIONALITY ===
function initServicesPage() {
  // Testimonial slider
  const testimonials = document.querySelectorAll('.testimonial');
  let currentTestimonial = 0;
  
  if (testimonials.length > 1) {
    // Show first testimonial
    testimonials[0].classList.add('active');
    
    // Auto-rotate testimonials
    setInterval(() => {
      testimonials[currentTestimonial].classList.remove('active');
      currentTestimonial = (currentTestimonial + 1) % testimonials.length;
      testimonials[currentTestimonial].classList.add('active');
    }, 5000);
  }
  
  // Service inquiry links
  const serviceInquiryLinks = document.querySelectorAll('.service-cta');
  serviceInquiryLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      if (window.location.pathname.includes('contact.html')) {
        e.preventDefault();
        const service = link.closest('.service-card').querySelector('h2').textContent;
        document.querySelector('#service').value = service;
        document.querySelector('#message').value = `I'm interested in your ${service} service. Please provide more information.`;
        document.querySelector('#message').focus();
      }
    });
  });
}

// === EMAIL VALIDATION ===
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

document.addEventListener('DOMContentLoaded', function () {
  const newsletterForm = document.querySelector('.newsletter-form');
  const contactForm = document.querySelector('.contact-form');

  if (newsletterForm) {
    newsletterForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const emailInput = this.querySelector('input[type="email"]');
      const btn = this.querySelector('button');
      const email = emailInput.value.trim();

      if (!email) return;

      btn.textContent = 'Subscribing...';
      btn.disabled = true;

      try {
        const response = await fetch('https://formspree.io/f/mnnzqwkz', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, type: 'newsletter' }),
        });

        if (!response.ok) throw new Error('Form submission failed');
        alert('Thank you for subscribing!');
        this.reset();
      } catch (error) {
        alert('Subscription failed. Please try again.');
        console.error(error);
      } finally {
        btn.textContent = 'Subscribe';
        btn.disabled = false;
      }
    });
  }

  if (contactForm) {
    contactForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const submitBtn = this.querySelector('.submit-btn');
      submitBtn.textContent = 'Sending...';
      submitBtn.disabled = true;

      const formData = {
        name: this.querySelector('#name')?.value.trim(),
        email: this.querySelector('#email')?.value.trim(),
        service: this.querySelector('#service')?.value,
        message: this.querySelector('#message')?.value.trim(),
      };

      if (!formData.name || !formData.email || !formData.message) {
        alert('Please fill in all required fields.');
        submitBtn.textContent = 'Send Message';
        submitBtn.disabled = false;
        return;
      }

      try {
        const response = await fetch('https://formspree.io/f/mnnzqwkz', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(formData),
        });

        if (!response.ok) throw new Error('Form submission failed');
        alert('Message sent successfully!');
        this.reset();
      } catch (error) {
        alert('Failed to send message. Please try again.');
        console.error(error);
      } finally {
        submitBtn.textContent = 'Send Message';
        submitBtn.disabled = false;
      }
    });
  }

  if (document.querySelector('.blog-grid')) {
    initBlogPage();
  }

  if (document.querySelector('.services-grid')) {
    initServicesPage();
  }

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
});
